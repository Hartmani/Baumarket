
create table users (
  id uuid primary key default gen_random_uuid(),
  name text,
  email text,
  phone text
);

create table projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id),
  city text,
  region text,
  build_type text,
  created_at timestamp default now()
);

create table requests (
  id uuid primary key default gen_random_uuid(),
  project_id uuid references projects(id),
  category text,
  quantity numeric,
  specification jsonb,
  score integer default 0
);

create table suppliers (
  id uuid primary key default gen_random_uuid(),
  company text,
  email text,
  category text,
  region text
);
