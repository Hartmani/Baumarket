
const requests = [
  {
    category: "Polystyren",
    region: "Kladno",
    quantity: "2200 m²"
  },
  {
    category: "Okna",
    region: "Kolín",
    quantity: "48 ks"
  }
];

export default function AdminPage() {
  return (
    <main style={{padding:40,fontFamily:"Arial"}}>
      <h1>Admin dashboard</h1>

      <table border={1} cellPadding={10}>
        <thead>
          <tr>
            <th>Kategorie</th>
            <th>Region</th>
            <th>Objem</th>
          </tr>
        </thead>

        <tbody>
          {requests.map((r, i) => (
            <tr key={i}>
              <td>{r.category}</td>
              <td>{r.region}</td>
              <td>{r.quantity}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  )
}
