
"use client";

import { useState } from "react";

export default function RequestPage() {
  const [submitted, setSubmitted] = useState(false);

  async function handleSubmit(e:any) {
    e.preventDefault();
    setSubmitted(true);
  }

  if (submitted) {
    return (
      <main style={{padding:40}}>
        <h1>Děkujeme</h1>
        <p>Vaše poptávka byla odeslána.</p>
      </main>
    )
  }

  return (
    <main style={{padding:40,fontFamily:"Arial"}}>
      <h1>Nová poptávka</h1>

      <form onSubmit={handleSubmit} style={{
        display:"flex",
        flexDirection:"column",
        gap:12,
        maxWidth:500
      }}>

        <input placeholder="Jméno" required />
        <input placeholder="Email" required />
        <input placeholder="Telefon" required />
        <input placeholder="Město" required />

        <select required>
          <option value="">Typ stavby</option>
          <option>Novostavba</option>
          <option>Rekonstrukce</option>
        </select>

        <label>
          <input type="checkbox" /> Cihly
        </label>

        <label>
          <input type="checkbox" /> Okna
        </label>

        <label>
          <input type="checkbox" /> Polystyren
        </label>

        <textarea
          placeholder="Detail poptávky"
          rows={6}
        />

        <button type="submit" style={{
          padding:"12px 20px",
          background:"black",
          color:"white",
          border:"none",
          borderRadius:8
        }}>
          Odeslat poptávku
        </button>
      </form>
    </main>
  )
}
